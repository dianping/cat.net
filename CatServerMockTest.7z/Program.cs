﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace CatServerMockTest
{
    internal class Program
    {
        private const int MyProt = 2280; //端口
        private static int _num;
        private static StreamWriter _sw;
        private static Socket _serverSocket;

        private static void Main()
        {
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "s.txt");
            //写文件
            var s = new FileStream(path, FileMode.OpenOrCreate);
            _sw = new StreamWriter(s, Encoding.UTF8);

            //服务器IP地址
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            _serverSocket.Bind(new IPEndPoint(ip, MyProt)); //绑定IP地址：端口
            _serverSocket.Listen(10000); //设定最多10个排队连接请求
            Console.WriteLine("启动监听{0}成功", _serverSocket.LocalEndPoint);
            //通过Clientsoket发送数据
            ThreadPool.QueueUserWorkItem(ListenClientConnect);
            Console.ReadLine();
            _sw.Close();
            Console.WriteLine(_num);
        }

        /// <summary>
        ///   监听客户端连接
        /// </summary>
        private static void ListenClientConnect(object obj)
        {
            while (true)
            {
                Socket clientSocket = _serverSocket.Accept();
                try
                {
                    ThreadPool.QueueUserWorkItem(ReceiveMessage, clientSocket);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    clientSocket.Shutdown(SocketShutdown.Both);
                    clientSocket.Close();
                    break;
                }
            }
        }

        /// <summary>
        ///   接收消息
        /// </summary>
        /// <param name="clientSocket"> </param>
        private static void ReceiveMessage(object clientSocket)
        {
            Socket myClientSocket = (Socket) clientSocket;
            while (true)
            {
                try
                {
                    //通过clientSocket接收数据
                    byte[] result = new byte[1024*1024];
                    int receiveNumber = myClientSocket.Receive(result);
                    var str = Encoding.UTF8.GetString(result, 0, receiveNumber);
                    Console.WriteLine("{2}接收客户端{0}消息{1}", myClientSocket.RemoteEndPoint, str, DateTime.Now);

                    _sw.Write(str);

                    _num += 1;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    myClientSocket.Shutdown(SocketShutdown.Both);
                    myClientSocket.Close();
                    break;
                }
            }
            //Console.WriteLine(DateTime.Now);
        }
    }
}